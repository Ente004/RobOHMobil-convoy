################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/VL53L4CX/platform/src/vl53lx_platform_ipp.c \
../Drivers/VL53L4CX/platform/src/vl53lx_platform_log.c 

OBJS += \
./Drivers/VL53L4CX/platform/src/vl53lx_platform_ipp.o \
./Drivers/VL53L4CX/platform/src/vl53lx_platform_log.o 

C_DEPS += \
./Drivers/VL53L4CX/platform/src/vl53lx_platform_ipp.d \
./Drivers/VL53L4CX/platform/src/vl53lx_platform_log.d 


# Each subdirectory must supply rules for building sources it contributes
Drivers/VL53L4CX/platform/src/%.o Drivers/VL53L4CX/platform/src/%.su Drivers/VL53L4CX/platform/src/%.cyclo: ../Drivers/VL53L4CX/platform/src/%.c Drivers/VL53L4CX/platform/src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -c -I../Core/Inc -I../Drivers/STM32G4xx_HAL_Driver/Inc -I../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../Drivers/CMSIS/Include -I"C:/Users/Anwender/Documents/Hochschule/Projekt - RobOHMobil Convoy/Github_RobOHMobil/RobOHMobil-convoy2/RobOHMobil-Follower/Drivers/STSW-IMG029" -I"C:/Users/TEMP.ADS1.002/Documents/RobOHMobil/RobOHMobil-convoy-master/RobOHMobil-Follower/Drivers/VL53L4CX/core/inc" -I"C:/Users/TEMP.ADS1.002/Documents/RobOHMobil/RobOHMobil-convoy-master/RobOHMobil-Follower/Drivers/VL53L4CX/platform/inc" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Drivers-2f-VL53L4CX-2f-platform-2f-src

clean-Drivers-2f-VL53L4CX-2f-platform-2f-src:
	-$(RM) ./Drivers/VL53L4CX/platform/src/vl53lx_platform_ipp.cyclo ./Drivers/VL53L4CX/platform/src/vl53lx_platform_ipp.d ./Drivers/VL53L4CX/platform/src/vl53lx_platform_ipp.o ./Drivers/VL53L4CX/platform/src/vl53lx_platform_ipp.su ./Drivers/VL53L4CX/platform/src/vl53lx_platform_log.cyclo ./Drivers/VL53L4CX/platform/src/vl53lx_platform_log.d ./Drivers/VL53L4CX/platform/src/vl53lx_platform_log.o ./Drivers/VL53L4CX/platform/src/vl53lx_platform_log.su

.PHONY: clean-Drivers-2f-VL53L4CX-2f-platform-2f-src

